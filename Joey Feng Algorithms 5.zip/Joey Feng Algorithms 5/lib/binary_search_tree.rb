# There are many ways to implement these methods, feel free to add arguments
# to methods as you see fit, or to create helper methods.
require 'bst_node'
require 'byebug'

class BinarySearchTree
  attr_accessor :root

  def initialize
    @root = nil
  end

  def insert(value)
    if @root
      node = @root
      while node
        if value < node.value
          unless node.left
            return node.left = BSTNode.new(value)
          end
          node = node.left
        else
          unless node.right
            return node.right = BSTNode.new(value)
          end
          node = node.right
        end
      end
    else
      @root = BSTNode.new(value)
    end
  end

  def find(value, tree_node = @root)
    node = tree_node
    while node
      if value < node.value
        if node.left
          @parent_node = node
          node = node.left
        else
          return nil
        end
      elsif value > node.value
        if node.right
          @parent_node = node
          node = node.right
        else
          return nil
        end
      else
        return node
      end
    end
  end

  def delete(value)
    # byebug
    found_node = self.find(value)
    if @root == found_node
      return @root = nil
    end
    if found_node
      parent = parent(found_node)
      if !found_node.left && !found_node.right
        if parent.left.value == value
          parent.left = nil
        elsif parent.right.value == value
          parent.right = nil
        end
      elsif number_of_children(found_node) == 1
        child = (found_node.left ? found_node.left : found_node.right)
        if parent.left == found_node
          parent.left = child
        else parent.right = child
        end
      end
    end
  end

  # helper method for #delete:
  def maximum(tree_node = @root)
    if tree_node.right
      max_node = maximum(tree_node.right)
    else
      max_node = tree_node
    end
    max_node
  end

  def depth(tree_node = @root)
  end

  def is_balanced?(tree_node = @root)
  end

  def in_order_traversal(tree_node = @root, arr = [])
  end


  private

  def parent(node)
    parent = @root
    while parent
      if parent.value > node.value
        return parent if parent.left == node
        parent = parent.left
      else
        return parent if parent.right == node
        parent = parent.right
      end
    end
    nil
  end

  def number_of_children(node)
    if node.left && node.right
      return 2
    elsif node.left || node.right
      return 1
    else
      return 0
    end
  end
  # optional helper methods go here:

end
