# Given an Array of tuples, where tuple[0] represents a package id,
# and tuple[1] represents its dependency, determine the order in which
# the packages should be installed. Only packages that have dependencies
# will be listed, but all packages from 1..max_id exist.

# N.B. this is how `npm` works.

# Import any files you need to



def install_order(arr)
  result = arr
  min = arr.map {|arr| arr[0]}.min
  max = arr.map {|arr| arr[0]}.max
  missing_indices = (min..max).to_a - arr.map {|arr| arr[0]}
  missing_indices.each do |idx|
    result.push([idx, 1])
  end
  p result
  result
end
